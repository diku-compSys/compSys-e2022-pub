
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// experiment with the different values
int M = 100; // rows
int N = 10; // columns
int bool_print_matrixes = 1;

// 32-bit

// long x = -2147483648;
// long y = 2147483647;

// 64-bit, specify with long long, to be sure its 64 bit

//  long long x = -9223372036854775808;
//  long long y = 9223372036854775807;



void print_matrix(long matrix[M][N]) {
     int i, j;

    //  printf("hej3");
    // For each element for the row_vector
    for (i = 0; i < M; i++) {
        // printf("hej3");
        
        // for each col in a row (each element in the row)
        for (j = 0; j < N; j++) {
            
            printf("%ld",matrix[i][j]);
            printf(" ");
            fflush(stdout);
        }
        printf("\n");
        fflush(stdout);
    }
}

long** row_vector_add(long row_vector[M], long matrix[M][N]) {
    int i, j;
    // For each element for the row_vector
    for (i = 0; i < M; i++) {
    // Add the element to each element of a column
        for (j = 0; j < N; j++) {
            matrix[i][j] += row_vector[i];
        }
    }
    return matrix;
}

long** col_vector_add(long row_vector[M], long matrix[M][N]) {
    int i, j;
    // For each element for the row_vector
    for (i = 0; i < N; i++) {
    // Add the element to each element of a column
        for (j = 0; j < M; j++) {
            matrix[j][i] += row_vector[j];
        }
    }
    return matrix;
}

void time_elapsed(int col,long row_vector[M], long matrix[M][N]){
    clock_t start = clock();
    if (col) {
        long** res_matrix = col_vector_add(row_vector,matrix);
    } else {
        long** res_matrix = row_vector_add(row_vector,matrix);
    }
    clock_t end = clock();
    double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time elapsed: %f seconds\n", elapsed);
}

void print_matrixes(long row_vector[M], long matrix[M][N]){
    long ** col_matrix = col_vector_add(row_vector, matrix);
    long ** row_matrix = row_vector_add(row_vector, matrix);
    printf("Printing col matrix \n");
    print_matrix(col_matrix);
    printf("\n");
    printf("Printing row matrix \n");
    print_matrix(row_matrix);
    printf("\n");
}

int main(int argc,char* argv[]) {
    // TODO get the command line inputs
    long start = 1;

    long row_vector[M];
    for (int i = 0; i < M; i++) {
        row_vector[i] = start;
        start += 1;
    }

    start = 1;
    long matrix[M][N];
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            matrix[i][j] = start;
            start += 1;
        }
    }

    // print_matrix(matrix);
    // printf("\n");

    time_elapsed(1,row_vector,matrix);

    time_elapsed(0,row_vector,matrix);
    
    if (bool_print_matrixes)
    {
        /* code */
        print_matrixes(row_vector,matrix);
    }
    
    // // TODO make compare function
    // printf("\n");
    // printf(res_matrix2 == res_matrix);
    return 0;
}
